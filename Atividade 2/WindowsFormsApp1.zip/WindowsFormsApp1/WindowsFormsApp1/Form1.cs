﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                MessageBox.Show("numero1 invalido!");
                txtnumero1.Focus();
            }

        }

        private void textnumero2_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtnumero2.Text, out numero2))
            {
                MessageBox.Show("numero2 invalido!");
                txtnumero2.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtNumero3.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtNumero3.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtNumero3.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtNumero3.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 ==0)
            {
                MessageBox.Show("número 2 inválido");
                txtnumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtNumero3.Text = resultado.ToString();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }
    }
}
